from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, Response
import sqlite3, os, csv, io, socket
from datetime import datetime
from functools import wraps

APP_NAME = "COMPUSYS"
BASE_DIR = os.path.dirname(__file__)
DB = os.path.join(BASE_DIR, "compusys.db")
app = Flask(__name__)
app.secret_key = "COMPUSYS-v3-cambiar-esta-clave"


def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def setting(conn, key, default=""):
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key, value):
    conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))


def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'cajero');
    CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL);
    CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, barcode TEXT, name TEXT NOT NULL, category_id INTEGER, brand TEXT, unit TEXT DEFAULT 'UND', purchase_price REAL DEFAULT 0, sale_price REAL DEFAULT 0, stock REAL DEFAULT 0, min_stock REAL DEFAULT 0, supplier_id INTEGER, cost_soles REAL DEFAULT 0, max_price REAL DEFAULT 0, card_price REAL DEFAULT 0, provider_price REAL DEFAULT 0, created_at TEXT NOT NULL, FOREIGN KEY(category_id) REFERENCES categories(id), FOREIGN KEY(supplier_id) REFERENCES suppliers(id));
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT, total REAL NOT NULL, payment_method TEXT NOT NULL, user_id INTEGER, created_at TEXT NOT NULL, customer_id INTEGER, cash_register_id INTEGER, document_type TEXT DEFAULT 'TICKET', series TEXT DEFAULT 'T001', number INTEGER DEFAULT 0, customer_name TEXT, customer_document TEXT, customer_address TEXT, notes TEXT, paid_amount REAL DEFAULT 0, change_amount REAL DEFAULT 0, status TEXT DEFAULT 'EMITIDO', FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER NOT NULL, quantity REAL NOT NULL, unit_price REAL NOT NULL, FOREIGN KEY(sale_id) REFERENCES sales(id), FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER, total REAL NOT NULL, user_id INTEGER, created_at TEXT NOT NULL, status TEXT DEFAULT 'REGISTRADA', cancelled_at TEXT, cancelled_by INTEGER, cancellation_reason TEXT, FOREIGN KEY(supplier_id) REFERENCES suppliers(id), FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(cancelled_by) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL, product_id INTEGER NOT NULL, quantity REAL NOT NULL, unit_cost REAL NOT NULL, FOREIGN KEY(purchase_id) REFERENCES purchases(id), FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS movements(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, movement_type TEXT NOT NULL, quantity REAL NOT NULL, reference TEXT, user_id INTEGER, created_at TEXT NOT NULL, FOREIGN KEY(product_id) REFERENCES products(id), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, document TEXT, phone TEXT, document_type TEXT DEFAULT 'DNI', address TEXT, email TEXT);
    CREATE TABLE IF NOT EXISTS cash_registers(id INTEGER PRIMARY KEY AUTOINCREMENT, opening_amount REAL NOT NULL DEFAULT 0, closing_amount REAL, opened_at TEXT NOT NULL, closed_at TEXT, user_id INTEGER, status TEXT NOT NULL DEFAULT 'OPEN', FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '');
    """)

    # Migrate older v2 databases safely.
    table_cols = {
        'sales': {r[1] for r in conn.execute('PRAGMA table_info(sales)').fetchall()},
        'purchases': {r[1] for r in conn.execute('PRAGMA table_info(purchases)').fetchall()},
        'customers': {r[1] for r in conn.execute('PRAGMA table_info(customers)').fetchall()},
    }
    for col, typ in [('customer_id','INTEGER'),('cash_register_id','INTEGER'),('document_type','TEXT DEFAULT \'TICKET\''),('series','TEXT DEFAULT \'T001\''),('number','INTEGER DEFAULT 0'),('customer_name','TEXT'),('customer_document','TEXT'),('customer_address','TEXT'),('notes','TEXT'),('paid_amount','REAL DEFAULT 0'),('change_amount','REAL DEFAULT 0'),('status','TEXT DEFAULT \'EMITIDO\'')]:
        if col not in table_cols['sales']:
            conn.execute(f'ALTER TABLE sales ADD COLUMN {col} {typ}')
    for col, typ in [('status','TEXT DEFAULT \'REGISTRADA\''),('cancelled_at','TEXT'),('cancelled_by','INTEGER'),('cancellation_reason','TEXT')]:
        if col not in table_cols['purchases']:
            conn.execute(f'ALTER TABLE purchases ADD COLUMN {col} {typ}')
    for col, typ in [('phone','TEXT'),('document_type','TEXT DEFAULT \'DNI\''),('address','TEXT'),('email','TEXT')]:
        if col not in table_cols['customers']:
            conn.execute(f'ALTER TABLE customers ADD COLUMN {col} {typ}')

    # Defaults/configuration.
    defaults = {
        'company_name':'COMPUSYS', 'company_ruc':'', 'company_address':'', 'company_phone':'', 'ticket_footer':'Gracias por su compra',
        'printer_mode':'browser', 'printer_name':'', 'printer_ip':'', 'printer_port':'9100', 'auto_print':'1', 'dni_ruc_api_token':'',
        'boleta_series':'B001', 'factura_series':'F001', 'ticket_series':'T001', 'pedido_series':'NP01'
    }
    for k,v in defaults.items():
        conn.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)',(k,v))

    if not conn.execute('SELECT 1 FROM users LIMIT 1').fetchone():
        conn.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)', ('admin','admin123','admin'))
    if not conn.execute('SELECT 1 FROM categories LIMIT 1').fetchone():
        for c in ['Cómputo','Oficina','Papelería','Accesorios','Limpieza','Otros']:
            conn.execute('INSERT OR IGNORE INTO categories(name) VALUES(?)',(c,))
    # Assign old generic products when they have no category.
    inv = conn.execute("SELECT id FROM categories WHERE name='Inventario inicial'").fetchone()
    if inv:
        conn.execute("UPDATE products SET category_id=NULL WHERE category_id=?", (inv['id'],))
    conn.commit(); conn.close()


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session: return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('Solo el administrador puede realizar esta acción.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return wrapper


def next_number(conn, series):
    row = conn.execute('SELECT COALESCE(MAX(number),0)+1 n FROM sales WHERE series=?', (series,)).fetchone()
    return int(row['n'])


def printer_config(conn):
    return {k: setting(conn,k) for k in ['printer_mode','printer_name','printer_ip','printer_port','auto_print']}


def print_raw_windows(printer_name, data):
    try:
        import win32print
        h = win32print.OpenPrinter(printer_name)
        try:
            win32print.StartDocPrinter(h, 1, ('COMPUSYS', None, 'RAW'))
            win32print.StartPagePrinter(h)
            win32print.WritePrinter(h, data)
            win32print.EndPagePrinter(h)
            win32print.EndDocPrinter(h)
        finally:
            win32print.ClosePrinter(h)
        return True, ''
    except Exception as e:
        return False, str(e)


def escpos_ticket(sale, items, company):
    enc='cp858'
    b=lambda s: (str(s)+'\n').encode(enc, errors='replace')
    out=b'\x1b@'
    out+=b'\x1b\x61\x01'+b'\x1b\x21\x10'+b(company.get('company_name','COMPUSYS'))+b'\x1b\x21\x00'
    if company.get('company_ruc'): out+=b('RUC: '+company['company_ruc'])
    if company.get('company_address'): out+=b(company['company_address'])
    out+=b('--------------------------------')
    out+=b(f"{sale['document_type']} {sale['series']}-{int(sale['number']):08d}")
    out+=b('Fecha: '+sale['created_at'])
    out+=b('Cliente: '+(sale['customer_name'] or 'Cliente general'))
    if sale['customer_document']: out+=b('Doc: '+sale['customer_document'])
    out+=b('--------------------------------')
    for i in items:
        out+=b(str(i['name'])[:42])
        out+=b(f"{i['quantity']:g} x S/ {i['unit_price']:.2f}    S/ {i['quantity']*i['unit_price']:.2f}")
    out+=b('--------------------------------')
    out+=b(f"TOTAL: S/ {sale['total']:.2f}")
    out+=b('Pago: '+sale['payment_method'])
    if sale['paid_amount']: out+=b(f"Recibido: S/ {sale['paid_amount']:.2f}")
    out+=b(f"Vuelto: S/ {sale['change_amount']:.2f}")
    out+=b('--------------------------------')
    out+=b(company.get('ticket_footer','Gracias por su compra'))
    out+=b'\n\n\n\x1dV\x00'
    return out


def direct_print(sale_id):
    conn=db(); sale=conn.execute('SELECT * FROM sales WHERE id=?',(sale_id,)).fetchone(); items=conn.execute('SELECT si.*,p.name FROM sale_items si JOIN products p ON p.id=si.product_id WHERE si.sale_id=? ORDER BY si.id',(sale_id,)).fetchall(); cfg=printer_config(conn); company={k:setting(conn,k) for k in ['company_name','company_ruc','company_address','ticket_footer']}; conn.close()
    if not sale or cfg['printer_mode']=='browser': return False, 'browser'
    data=escpos_ticket(sale,items,company)
    if cfg['printer_mode']=='network':
        try:
            with socket.create_connection((cfg['printer_ip'], int(cfg['printer_port'] or 9100)), timeout=4) as s: s.sendall(data)
            return True, 'network'
        except Exception as e: return False, str(e)
    if cfg['printer_mode']=='windows': return print_raw_windows(cfg['printer_name'], data)
    return False, 'Modo de impresora no válido'


@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        conn=db(); user=conn.execute('SELECT * FROM users WHERE username=? AND password=?',(u,p)).fetchone(); conn.close()
        if user:
            session.update(user_id=user['id'], username=user['username'], role=user['role']); return redirect(url_for('dashboard'))
        flash('Usuario o contraseña incorrectos.','danger')
    return render_template('login.html', app_name=APP_NAME)

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    conn=db(); today=datetime.now().strftime('%Y-%m-%d')
    products=conn.execute('SELECT COUNT(*) n FROM products').fetchone()['n']; low=conn.execute('SELECT COUNT(*) n FROM products WHERE stock<=min_stock').fetchone()['n']; stock_value=conn.execute('SELECT COALESCE(SUM(stock*purchase_price),0) v FROM products').fetchone()['v']; sales=conn.execute("SELECT COALESCE(SUM(total),0) v FROM sales WHERE date(created_at)=? AND status!='ANULADO'",(today,)).fetchone()['v']; profit=conn.execute("SELECT COALESCE(SUM(si.quantity*(si.unit_price-p.purchase_price)),0) v FROM sale_items si JOIN sales s ON s.id=si.sale_id JOIN products p ON p.id=si.product_id WHERE date(s.created_at)=? AND s.status!='ANULADO'",(today,)).fetchone()['v']; recent=conn.execute("SELECT s.id,s.total,s.payment_method,s.document_type,s.series,s.number,s.created_at,u.username FROM sales s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 8").fetchall(); conn.close()
    return render_template('dashboard.html',products=products,low=low,stock_value=stock_value,sales=sales,profit=profit,recent=recent)

@app.route('/products', methods=['GET','POST'])
@login_required
def products():
    conn=db()
    if request.method=='POST':
        try:
            d=request.form
            conn.execute("INSERT INTO products(code,barcode,name,category_id,brand,unit,purchase_price,sale_price,stock,min_stock,supplier_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(d['code'].strip(),d.get('barcode'),d['name'].strip(),d.get('category_id') or None,d.get('brand'),d.get('unit') or 'UND',float(d.get('purchase_price') or 0),float(d.get('sale_price') or 0),float(d.get('stock') or 0),float(d.get('min_stock') or 0),d.get('supplier_id') or None,datetime.now().isoformat(timespec='seconds'))); conn.commit(); flash('Producto registrado correctamente.','success')
        except sqlite3.IntegrityError: flash('El código del producto ya existe.','danger')
        except ValueError: flash('Revisa los valores numéricos.','danger')
        return redirect(url_for('products'))
    rows=conn.execute('SELECT p.*,c.name category,s.name supplier FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN suppliers s ON s.id=p.supplier_id ORDER BY p.name COLLATE NOCASE').fetchall(); cats=conn.execute('SELECT c.id,c.name,COUNT(p.id) product_count FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id ORDER BY c.name COLLATE NOCASE').fetchall(); sups=conn.execute('SELECT * FROM suppliers ORDER BY name').fetchall(); stats=conn.execute('SELECT COUNT(*) products,COALESCE(SUM(stock),0) units,COALESCE(SUM(stock*purchase_price),0) stock_value,COALESCE(SUM(CASE WHEN stock<=min_stock THEN 1 ELSE 0 END),0) low_stock FROM products').fetchone(); conn.close()
    return render_template('products.html',products=rows,categories=cats,suppliers=sups,stats=stats)

@app.route('/products/export')
@login_required
def products_export():
    conn=db(); rows=conn.execute('SELECT p.code,p.barcode,p.name,c.name category,p.brand,p.unit,p.stock,p.min_stock,p.purchase_price,p.sale_price FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.name COLLATE NOCASE').fetchall(); conn.close(); out=io.StringIO(); w=csv.writer(out); w.writerow(['Código','Código de barras','Producto','Categoría','Marca','Unidad','Stock','Stock mínimo','Precio compra','Precio venta']); [w.writerow([r[k] for k in r.keys()]) for r in rows]; return Response('\ufeff'+out.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename=COMPUSYS_inventario.csv'})

@app.route('/products/delete/<int:pid>', methods=['POST'])
@login_required
@admin_required
def product_delete(pid):
    conn=db()
    try: conn.execute('DELETE FROM products WHERE id=?',(pid,)); conn.commit(); flash('Producto eliminado.','success')
    except sqlite3.IntegrityError: flash('No se puede eliminar porque tiene movimientos asociados.','danger')
    conn.close(); return redirect(url_for('products'))

@app.route('/suppliers', methods=['GET','POST'])
@login_required
def suppliers():
    conn=db()
    if request.method=='POST': conn.execute('INSERT INTO suppliers(name,phone,address) VALUES(?,?,?)',(request.form['name'],request.form.get('phone'),request.form.get('address'))); conn.commit(); flash('Proveedor registrado.','success'); return redirect(url_for('suppliers'))
    rows=conn.execute('SELECT * FROM suppliers ORDER BY name').fetchall(); conn.close(); return render_template('suppliers.html',suppliers=rows)

@app.route('/purchases', methods=['GET','POST'])
@login_required
def purchases():
    conn=db()
    if request.method=='POST':
        try:
            ids=request.form.getlist('product_id'); qs=request.form.getlist('quantity'); cs=request.form.getlist('cost'); supplier_id=request.form.get('supplier_id') or None; items=[]; total=0
            for pid,q,c in zip(ids,qs,cs):
                q=float(q); c=float(c)
                if q>0: items.append((int(pid),q,c)); total+=q*c
            if not items: raise ValueError('Agrega al menos un producto.')
            now=datetime.now().isoformat(timespec='seconds'); cur=conn.execute('INSERT INTO purchases(supplier_id,total,user_id,created_at,status) VALUES(?,?,?,?,?)',(supplier_id,total,session['user_id'],now,'REGISTRADA')); purchase_id=cur.lastrowid
            for pid,q,c in items:
                conn.execute('INSERT INTO purchase_items(purchase_id,product_id,quantity,unit_cost) VALUES(?,?,?,?)',(purchase_id,pid,q,c)); conn.execute('UPDATE products SET stock=stock+?,purchase_price=? WHERE id=?',(q,c,pid)); conn.execute('INSERT INTO movements(product_id,movement_type,quantity,reference,user_id,created_at) VALUES(?,?,?,?,?,?)',(pid,'ENTRADA',q,f'COMPRA #{purchase_id}',session['user_id'],now))
            conn.commit(); flash(f'Compra #{purchase_id} registrada por S/ {total:.2f}.','success')
        except Exception as e: conn.rollback(); flash(str(e),'danger')
        return redirect(url_for('purchases'))
    rows=conn.execute('SELECT id,code,barcode,name,purchase_price,sale_price,stock FROM products ORDER BY name').fetchall(); sups=conn.execute('SELECT * FROM suppliers ORDER BY name').fetchall(); history=conn.execute('SELECT p.*,s.name supplier,u.username FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id LEFT JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 100').fetchall(); conn.close(); return render_template('purchases.html',products=rows,suppliers=sups,history=history)

@app.route('/purchases/delete/<int:purchase_id>', methods=['POST'])
@login_required
@admin_required
def purchase_delete(purchase_id):
    conn=db(); p=conn.execute('SELECT * FROM purchases WHERE id=?',(purchase_id,)).fetchone()
    if not p: conn.close(); flash('Compra no encontrada.','danger'); return redirect(url_for('purchases'))
    if p['status']=='ANULADA': conn.close(); flash('La compra ya está anulada.','warning'); return redirect(url_for('purchases'))
    try:
        items=conn.execute('SELECT * FROM purchase_items WHERE purchase_id=?',(purchase_id,)).fetchall(); now=datetime.now().isoformat(timespec='seconds')
        for i in items:
            prod=conn.execute('SELECT stock FROM products WHERE id=?',(i['product_id'],)).fetchone()
            if not prod or prod['stock'] < i['quantity']: raise ValueError(f"No se puede anular: stock insuficiente para revertir {i['quantity']} unidades del producto #{i['product_id']}.")
        for i in items:
            conn.execute('UPDATE products SET stock=stock-? WHERE id=?',(i['quantity'],i['product_id'])); conn.execute('INSERT INTO movements(product_id,movement_type,quantity,reference,user_id,created_at) VALUES(?,?,?,?,?,?)',(i['product_id'],'ANULACION_COMPRA',-i['quantity'],f'ANULA COMPRA #{purchase_id}',session['user_id'],now))
        conn.execute("UPDATE purchases SET status='ANULADA',cancelled_at=?,cancelled_by=?,cancellation_reason=? WHERE id=?",(now,session['user_id'],request.form.get('reason') or 'Error de registro',purchase_id)); conn.commit(); flash(f'Compra #{purchase_id} anulada y stock revertido.','success')
    except Exception as e: conn.rollback(); flash(str(e),'danger')
    conn.close(); return redirect(url_for('purchases'))

@app.route('/customers', methods=['GET','POST'])
@login_required
def customers():
    conn=db()
    if request.method=='POST':
        conn.execute('INSERT INTO customers(name,document,phone,document_type,address,email) VALUES(?,?,?,?,?,?)',(request.form['name'],request.form.get('document'),request.form.get('phone'),request.form.get('document_type') or 'DNI',request.form.get('address'),request.form.get('email'))); conn.commit(); flash('Cliente registrado.','success'); return redirect(url_for('customers'))
    rows=conn.execute('SELECT * FROM customers ORDER BY name').fetchall(); conn.close(); return render_template('customers.html',customers=rows)

@app.route('/sales')
@login_required
def sales():
    conn=db(); rows=conn.execute('SELECT s.*,u.username FROM sales s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 200').fetchall(); conn.close(); return render_template('sales.html',sales=rows)

@app.route('/pos')
@login_required
def pos():
    conn=db(); opened=conn.execute("SELECT * FROM cash_registers WHERE status='OPEN' ORDER BY id DESC LIMIT 1").fetchone(); cats=conn.execute('SELECT id,name FROM categories ORDER BY name').fetchall(); customers_rows=conn.execute('SELECT * FROM customers ORDER BY name LIMIT 500').fetchall(); cfg=printer_config(conn); conn.close(); return render_template('pos.html',opened=opened,categories=cats,customers=customers_rows,printer=cfg)

@app.route('/pos/sale', methods=['POST'])
@login_required
def pos_sale():
    conn=db()
    try:
        cash=conn.execute("SELECT * FROM cash_registers WHERE status='OPEN' ORDER BY id DESC LIMIT 1").fetchone()
        if not cash: raise ValueError('Debes abrir la caja antes de registrar una venta.')
        ids=request.form.getlist('product_id'); qs=request.form.getlist('quantity'); ps=request.form.getlist('price'); items=[]; total=0
        for pid,q,p in zip(ids,qs,ps):
            q=float(q or 0); p=float(p or 0)
            if q<=0: continue
            prod=conn.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
            if not prod: raise ValueError('Producto no encontrado.')
            if prod['stock']<q: raise ValueError(f'Stock insuficiente para {prod["name"]}.')
            if p<=0: p=float(prod['sale_price'] or 0)
            items.append((int(pid),q,p)); total+=q*p
        if not items: raise ValueError('Agrega al menos un producto.')
        doc_type=request.form.get('document_type') or 'TICKET'; docmap={'TICKET':'ticket_series','BOLETA':'boleta_series','FACTURA':'factura_series','NOTA DE PEDIDO':'pedido_series'}; conn_series_key=docmap.get(doc_type,'ticket_series'); series=setting(conn,conn_series_key)
        document=request.form.get('customer_document','').strip(); cname=request.form.get('customer_name','').strip(); caddr=request.form.get('customer_address','').strip(); customer_id=request.form.get('customer_id') or None
        if doc_type=='FACTURA' and (len(document)!=11 or not document.isdigit()): raise ValueError('Para factura debes indicar un RUC válido de 11 dígitos.')
        if doc_type=='BOLETA' and document and (len(document)!=8 or not document.isdigit()): raise ValueError('El DNI de la boleta debe tener 8 dígitos.')
        paid=float(request.form.get('paid_amount') or 0); change=max(paid-total,0) if request.form.get('payment_method')=='Efectivo' else 0
        if request.form.get('payment_method')=='Efectivo' and paid<total: raise ValueError('El monto recibido es menor al total.')
        now=datetime.now().isoformat(timespec='seconds'); num=next_number(conn,series)
        cur=conn.execute('INSERT INTO sales(total,payment_method,user_id,created_at,customer_id,cash_register_id,document_type,series,number,customer_name,customer_document,customer_address,notes,paid_amount,change_amount,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(total,request.form.get('payment_method') or 'Efectivo',session['user_id'],now,customer_id,cash['id'],doc_type,series,num,cname or None,document or None,caddr or None,request.form.get('notes'),paid,change,'EMITIDO')); sale_id=cur.lastrowid
        for pid,q,p in items:
            conn.execute('INSERT INTO sale_items(sale_id,product_id,quantity,unit_price) VALUES(?,?,?,?)',(sale_id,pid,q,p)); conn.execute('UPDATE products SET stock=stock-? WHERE id=?',(q,pid)); conn.execute('INSERT INTO movements(product_id,movement_type,quantity,reference,user_id,created_at) VALUES(?,?,?,?,?,?)',(pid,'SALIDA',q,f'{doc_type} {series}-{num:08d}',session['user_id'],now))
        conn.commit()
        printed=False; msg='browser'
        if setting(conn,'auto_print','1')=='1': printed,msg=direct_print(sale_id)
        return redirect(url_for('ticket',sid=sale_id,printed='1' if printed else '0'))
    except Exception as e: conn.rollback(); flash(str(e),'danger'); return redirect(url_for('pos'))
    finally: conn.close()

@app.route('/ticket/<int:sid>')
@login_required
def ticket(sid):
    conn=db(); sale=conn.execute('SELECT s.*,u.username FROM sales s LEFT JOIN users u ON u.id=s.user_id WHERE s.id=?',(sid,)).fetchone(); items=conn.execute('SELECT si.*,p.name,p.code FROM sale_items si JOIN products p ON p.id=si.product_id WHERE si.sale_id=? ORDER BY si.id',(sid,)).fetchall(); company={k:setting(conn,k) for k in ['company_name','company_ruc','company_address','company_phone','ticket_footer']}; conn.close();
    if not sale: flash('Documento no encontrado.','danger'); return redirect(url_for('sales'))
    return render_template('ticket.html',sale=sale,items=items,company=company,printed=request.args.get('printed')=='1')

@app.route('/api/products')
@login_required
def api_products():
    q=request.args.get('q','').strip(); cat=request.args.get('category','').strip(); conn=db(); params=[]; where=['p.stock>0']
    if q: where.append('(p.name LIKE ? OR p.code LIKE ? OR COALESCE(p.barcode,\'\') LIKE ? OR COALESCE(p.brand,\'\') LIKE ?)'); params += [f'%{q}%',f'%{q}%',f'%{q}%',f'%{q}%']
    if cat: where.append('p.category_id=?'); params.append(cat)
    rows=conn.execute(f"SELECT p.id,p.code,p.barcode,p.name,p.brand,p.sale_price,p.stock,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE {' AND '.join(where)} ORDER BY p.name LIMIT 60",params).fetchall(); conn.close(); return jsonify([dict(r) for r in rows])

@app.route('/api/customers')
@login_required
def api_customers():
    q=request.args.get('q','').strip(); conn=db(); rows=conn.execute("SELECT * FROM customers WHERE name LIKE ? OR document LIKE ? ORDER BY name LIMIT 30",(f'%{q}%',f'%{q}%')).fetchall(); conn.close(); return jsonify([dict(r) for r in rows])

@app.route('/api/document-lookup')
@login_required
def document_lookup():
    number=''.join(ch for ch in request.args.get('number','') if ch.isdigit())
    if len(number) not in (8,11): return jsonify({'ok':False,'error':'Ingresa un DNI de 8 dígitos o RUC de 11 dígitos.'}),400
    conn=db(); local=conn.execute('SELECT * FROM customers WHERE document=? LIMIT 1',(number,)).fetchone(); token=setting(conn,'dni_ruc_api_token',''); conn.close()
    if local: return jsonify({'ok':True,'source':'local','customer':dict(local)})
    if not token: return jsonify({'ok':False,'error':'No encontrado localmente. Configura el token de consulta DNI/RUC en Administración > Configuración para consultar datos externos.'}),404
    try:
        import requests
        if len(number)==8: url='https://api.decolecta.com/v1/reniec/dni'
        else: url='https://api.decolecta.com/v1/sunat/ruc'
        r=requests.get(url,params={'numero':number},headers={'Authorization':'Bearer '+token,'Accept':'application/json'},timeout=8)
        if r.status_code!=200: return jsonify({'ok':False,'error':f'No se encontró el documento o el servicio respondió {r.status_code}.'}),404
        data=r.json(); name=data.get('nombre') or data.get('razonSocial') or data.get('nombres') or ''; address=data.get('direccion') or ''
        return jsonify({'ok':True,'source':'api','customer':{'name':name,'document':number,'document_type':'DNI' if len(number)==8 else 'RUC','address':address}})
    except Exception as e: return jsonify({'ok':False,'error':'No fue posible consultar el servicio externo: '+str(e)}),502

@app.route('/cash', methods=['GET','POST'])
@login_required
def cash():
    conn=db(); opened=conn.execute("SELECT * FROM cash_registers WHERE status='OPEN' ORDER BY id DESC LIMIT 1").fetchone()
    if request.method=='POST':
        try:
            action=request.form.get('action'); now=datetime.now().isoformat(timespec='seconds')
            if action=='open':
                if opened: raise ValueError('Ya existe una caja abierta.')
                conn.execute("INSERT INTO cash_registers(opening_amount,opened_at,user_id,status) VALUES(?,?,?,'OPEN')",(float(request.form.get('amount') or 0),now,session['user_id']))
            else:
                if not opened: raise ValueError('No hay caja abierta.')
                conn.execute("UPDATE cash_registers SET closing_amount=?,closed_at=?,status='CLOSED' WHERE id=?",(float(request.form.get('amount') or 0),now,opened['id']))
            conn.commit(); flash('Operación de caja realizada.','success')
        except Exception as e: conn.rollback(); flash(str(e),'danger')
        return redirect(url_for('cash'))
    history=conn.execute('SELECT c.*,u.username FROM cash_registers c LEFT JOIN users u ON u.id=c.user_id ORDER BY c.id DESC LIMIT 30').fetchall(); conn.close(); return render_template('cash.html',opened=opened,history=history)

@app.route('/reports')
@login_required
def reports():
    conn=db(); low=conn.execute('SELECT * FROM products WHERE stock<=min_stock ORDER BY stock').fetchall(); moves=conn.execute('SELECT m.*,p.name product,u.username FROM movements m JOIN products p ON p.id=m.product_id LEFT JOIN users u ON u.id=m.user_id ORDER BY m.id DESC LIMIT 150').fetchall(); conn.close(); return render_template('reports.html',low=low,moves=moves)

@app.route('/users', methods=['GET','POST'])
@login_required
@admin_required
def users():
    conn=db()
    if request.method=='POST':
        try: conn.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',(request.form['username'],request.form['password'],request.form['role'])); conn.commit(); flash('Usuario creado.','success')
        except sqlite3.IntegrityError: flash('Ese usuario ya existe.','danger')
        return redirect(url_for('users'))
    rows=conn.execute('SELECT id,username,role FROM users ORDER BY username').fetchall(); conn.close(); return render_template('users.html',users=rows)

@app.route('/settings', methods=['GET','POST'])
@login_required
@admin_required
def settings():
    conn=db()
    if request.method=='POST':
        keys=['company_name','company_ruc','company_address','company_phone','ticket_footer','printer_mode','printer_name','printer_ip','printer_port','auto_print','dni_ruc_api_token','boleta_series','factura_series','ticket_series','pedido_series']
        for k in keys: set_setting(conn,k,request.form.get(k,''))
        conn.commit(); flash('Configuración guardada.','success'); return redirect(url_for('settings'))
    vals={k:setting(conn,k) for k in ['company_name','company_ruc','company_address','company_phone','ticket_footer','printer_mode','printer_name','printer_ip','printer_port','auto_print','dni_ruc_api_token','boleta_series','factura_series','ticket_series','pedido_series']}
    conn.close(); return render_template('settings.html',s=vals)

@app.context_processor
def inject_cash_status():
    if 'user_id' not in session: return {'cash_open':False,'opened':None}
    conn=db(); opened=conn.execute("SELECT * FROM cash_registers WHERE status='OPEN' ORDER BY id DESC LIMIT 1").fetchone(); conn.close(); return {'cash_open':bool(opened),'opened':opened}

if __name__=='__main__':
    init_db(); app.run(host='0.0.0.0',port=5000,debug=False)
