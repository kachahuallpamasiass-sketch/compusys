COMPUSYS v3 - SISTEMA COMERCIAL

FUNCIONES PRINCIPALES
- Inventario con 682 productos cargados y categorías.
- POS con búsqueda rápida por nombre, código y código de barras.
- Compatible con lector de código de barras como teclado.
- Boleta, factura, ticket y nota de pedido con series correlativas.
- Búsqueda de cliente por DNI/RUC y guardado de datos.
- Consulta externa DNI/RUC mediante token configurable (opcional).
- Cálculo de monto recibido y vuelto.
- Compras con búsqueda rápida de productos.
- Anulación de compras: revierte stock y deja auditoría del movimiento.
- Impresión desde POS: navegador, impresora Windows directa o impresora térmica de red.
- Configuración de empresa, series y pie de ticket.
- Usuarios y roles.
- Caja y reportes.

INSTALACIÓN WINDOWS
1. Instala Python 3.11+ y marca Add Python to PATH.
2. Ejecuta start_compusys.bat.
3. Abre http://127.0.0.1:5000
4. Usuario inicial: admin
5. Contraseña inicial: admin123

SEGURIDAD
La pantalla de login ya NO muestra usuario ni contraseña. Cambia la contraseña del usuario administrador desde el módulo de usuarios (la versión actual mantiene el mecanismo simple de v2; para producción se recomienda migrar a contraseñas con hash y CSRF).

IMPRESORA
- Navegador: al cobrar abre el ticket para imprimir manualmente.
- Windows directa: coloca el nombre exacto de la impresora en Configuración. La PC que ejecuta COMPUSYS debe tener la impresora instalada. Requiere pywin32.
- Red: coloca IP y puerto 9100 si la impresora térmica acepta RAW/ESC-POS.

DNI/RUC
La consulta externa requiere un token de un proveedor de API. COMPUSYS lo guarda en Configuración y consulta desde el backend, no desde JavaScript. Si no hay token, el sistema sigue permitiendo buscar clientes previamente registrados.

FACTURACIÓN ELECTRÓNICA
Esta versión organiza y numera documentos de venta y prepara los datos de boleta/factura, pero NO afirma que los envía a SUNAT. Para emisión electrónica real se necesita integrar el proveedor/OSE/PSE o API autorizado, credenciales y certificado según la modalidad elegida.

RED DE 3 PC
Ejecuta COMPUSYS en una PC servidor y desde las otras PCs abre http://IP_DEL_SERVIDOR:5000. Para impresión directa, la impresora debe estar conectada/configurada en la PC que ejecuta el servidor, o ser una impresora térmica de red accesible por IP.
